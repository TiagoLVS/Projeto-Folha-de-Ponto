export type Day = { date: string; entry: string; breakStart: string; breakEnd: string; exit: string; note: string };
export type Sheet = { days: Day[]; complete: boolean; updatedAt: string };
export type Professor = { id: string; name: string; registration: string; email: string; department: string; sheets: Record<string, Sheet> };
export type Status = "Preenchida" | "Em andamento" | "Não preenchida";
export function monthLabel(month: string) { const [year, m] = month.split("-").map(Number); return new Intl.DateTimeFormat("pt-BR", { month: "long", year: "numeric", timeZone: "UTC" }).format(new Date(Date.UTC(year, m - 1, 1))).replace(/^./, c => c.toUpperCase()); }
const minutes = (time: string) => { if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(time)) return NaN; const [h, m] = time.split(":").map(Number); return h * 60 + m; };
export function validateDay(day: Day, month: string): string | null {
  const date = new Date(day.date + "T12:00:00Z");
  if (!day.date.startsWith(month + "-") || !Number.isFinite(date.getTime()) || date.toISOString().slice(0, 10) !== day.date) return "A data precisa ser válida e pertencer à competência selecionada.";
  const [a, b, c, d] = [day.entry, day.breakStart, day.breakEnd, day.exit].map(minutes);
  if (![a, b, c, d].every(Number.isFinite)) return `Preencha todos os horários de ${day.date.split("-").reverse().join("/")}.`;
  if (!(a < b && b <= c && c < d)) return `Os horários de ${day.date.split("-").reverse().join("/")} precisam estar em ordem: entrada, intervalo, retorno e saída.`;
  return null;
}
export function totalMinutes(days: Day[]) { return days.reduce((sum, day) => { const [a, b, c, d] = [day.entry, day.breakStart, day.breakEnd, day.exit].map(minutes); return sum + ([a, b, c, d].every(Number.isFinite) && a < b && b <= c && c < d ? b - a + d - c : 0); }, 0); }
export function formatHours(total: number) { const h = Math.floor(total / 60), m = total % 60; return `${h} h${m ? ` ${String(m).padStart(2, "0")} min` : ""}`; }
export function sheetStatus(sheet?: Sheet): Status { return !sheet?.days.length ? "Não preenchida" : sheet.complete ? "Preenchida" : "Em andamento"; }
export function createDemoData(): Professor[] {
  const people = [["Ana Souza", "Ciências da Educação"], ["Carlos Lima", "Tecnologia da Informação"], ["Mariana Alves", "Ciências da Saúde"], ["Pedro Santos", "Ciências Humanas"], ["Beatriz Costa", "Gestão e Negócios"], ["Lucas Ferreira", "Ciências Exatas"], ["Juliana Rocha", "Ciências da Educação"], ["Rafael Oliveira", "Tecnologia da Informação"]];
  return people.map(([name, department], i) => {
    const sheets: Record<string, Sheet> = {};
    for (let month = 4; month <= 9; month++) {
      const count = month === 9 ? [15, 8, 0, 14, 16, 0, 12, 6][i] : month === 7 && i === 0 ? 0 : 14 + (i + month) % 4;
      const period = `2026-${String(month).padStart(2, "0")}`;
      const weekdays = Array.from({ length: 30 }, (_, j) => j + 1).filter(d => { const dow = new Date(2026, month - 1, d).getDay(); return dow !== 0 && dow !== 6; });
      sheets[period] = { days: weekdays.slice(0, count).map(day => ({ date: `${period}-${String(day).padStart(2, "0")}`, entry: "08:00", breakStart: "12:00", breakEnd: "13:00", exit: "17:00", note: "" })), complete: count > 0 && !(month === 9 && [1, 7].includes(i)), updatedAt: `${period}-22T12:00:00.000Z` };
    }
    return { id: String(i + 1), name, department, registration: String(20261001 + i), email: name.toLowerCase().replace(/ /g, ".") + "@example.com", sheets };
  });
}
